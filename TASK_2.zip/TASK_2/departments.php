<?php
include 'connection.php';
if(!isset( $_SESSION['user_id'] )){
    header("location:login.php");
}
$page=isset($_GET['page'])?mysqli_real_escape_string($connect,$_GET['page']):1;
$limit=6;
$offset=($page-1)*$limit;
$selectAll="SELECT count(*) as total FROM department";
$runSelectAll=mysqli_query($connect,$selectAll);
$totalUser=mysqli_fetch_array($runSelectAll);
$totalPages=$totalUser['total'];
$numberOfPages=ceil($totalPages/$limit);
$selectDepartments="SELECT * FROM department left join employee on department.departmentHead=employee.EmployeeId limit $limit OFFSET $offset";
$runDepartments=mysqli_query($connect,$selectDepartments);


if(isset($_GET['delete'])){
    $id=$_GET['delete'];
    $delete="DELETE from department where departmentId=$id";
    $runDelete=mysqli_query($connect,$delete);

    header("location:department.php");
}

if(isset($_POST['searchBtn'])){
    $text=$_POST['searchText'];
    $search="SELECT  * FROM `department` 
    left join  `employee` on `employee`.`EmployeeId`=`department`.`departmentHead`
     where 
     `EmployeeName` like '%$text%' or
      `department`.`departmentName` like '%$text%' ";
$runSearch=mysqli_query($connect,$search);
}

if(isset($_POST['sortingBtn'])){
    $sorting = $_POST['sorting']; // Set a default sorting column if none is provided
    $select="SELECT * FROM department left join employee on department.departmentHead=employee.EmployeeId order by $sorting";
    $runSort=mysqli_query($connect,$select);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department Management</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            padding: 30px 0;
        }
        .container {
            max-width: 1200px;
        }
        .input-group {
            margin-bottom: 30px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .card-title {
            font-size: 1.25rem;
        }
        .card-subtitle {
            font-size: 1rem;
            color: #6c757d;
        }
        .pagination {
            margin-top: 20px;
        }
        .pagination .page-item.active .page-link {
            background-color: #007bff;
            border-color: #007bff;
        }
        .pagination .page-link {
            color: #007bff;
            border-radius: 50%;
        }
        .page-link:hover {
            background-color: #e9ecef;
        }
        .fa-plus {
            font-size: 1.5rem;
            margin-left: 15px;
            color: #007bff;
        }
        .fa-plus:hover {
            color: #0056b3;
        }
select{
    border-radius: 5px;
}
    </style>
</head>
<body>
<br><br>
    <div class="container">
        <!-- Search Form -->
        <form method="post" class="d-flex justify-content-center">
            <div class="input-group">
                <input type="text" class="form-control" name="searchText" placeholder="Search department or head..." aria-label="Search">
                <button class="btn btn-outline-secondary" type="submit" name="searchBtn">
                    <i class="fa fa-search"></i>
                </button>
                <a href="addDepartment.php" class="btn btn-outline-primary" id="anchor">
                    <i class="fa-solid fa-plus"></i>
                </a>
            </div>
        </form>
        <form  method="POST">        
                                    <div class="result-sorting">
                                             <span>Sort By:</span>
                       
<select class="form" name="sorting" id="exampleOption">
<option value="departmentName ASC">Department (A-Z)</option>
<option value="departmentName DESC">Department (Z-A)</option>
</select>
<button type="submit" name="sortingBtn" class="btn btn-base">
<i class="fa-solid fa-sort"></i>
</button>
</div>
</form>    
        <div class="row">
        <?php if(isset($_POST['sortingBtn'])) { ?>
                <?php foreach($runSort as $data) { ?>
                    <?php 
                    $id = $data['departmentId'];
                    $select = "SELECT count(*) as total FROM employee WHERE DepartmentId=$id";
                    $run = mysqli_query($connect, $select);
                    $fetch = mysqli_fetch_array($run);
                    $count = $fetch['total'];
                    ?>
                    
                    <!-- Department Card -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $data['departmentName']; ?></h5>
                                <h6 class="card-subtitle">Department Head: <strong><?php echo ucfirst($data['EmployeeName']); ?></strong></h6>
                                <p class="card-text">Number of Employees: <?php echo $count; ?></p>
                                <a href="addDepartment.php?editDepart=<?php echo $data['departmentId']; ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="departments.php?delete=<?php echo $data['departmentId']; ?>" class="btn btn-sm btn-outline-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
           
            <?php }elseif(isset($_POST['searchBtn'])) { ?>
                <?php foreach($runSearch as $data) { ?>
                    <?php 
                    $id = $data['departmentId'];
                    $select = "SELECT count(*) as total FROM employee WHERE DepartmentId=$id";
                    $run = mysqli_query($connect, $select);
                    $fetch = mysqli_fetch_array($run);
                    $count = $fetch['total'];
                    ?>
                    
                    <!-- Department Card -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $data['departmentName']; ?></h5>
                                <h6 class="card-subtitle">Department Head: <strong><?php echo ucfirst($data['EmployeeName']); ?></strong></h6>
                                <p class="card-text">Number of Employees: <?php echo $count; ?></p>
                                <a href="addDepartment.php?editDepart=<?php echo $data['departmentId']; ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="departments.php?delete=<?php echo $data['departmentId']; ?>" class="btn btn-sm btn-outline-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <?php foreach($runDepartments as $data) { ?>
                    <?php 
                    $id = $data['departmentId'];
                    $select = "SELECT count(*) as total FROM employee WHERE DepartmentId=$id";
                    $run = mysqli_query($connect, $select);
                    $fetch = mysqli_fetch_array($run);
                    $count = $fetch['total'];
                    ?>
                    
                    <!-- Department Card -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $data['departmentName']; ?></h5>
                                <h6 class="card-subtitle">Department Head: <strong><?php echo ucfirst($data['EmployeeName']); ?></strong></h6>
                                <p class="card-text">Number of Employees: <?php echo $count; ?></p>
                                <a href="addDepartment.php?editDepart=<?php echo $data['departmentId']; ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="departments.php?delete=<?php echo $data['departmentId']; ?>" class="btn btn-sm btn-outline-danger">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>

        <!-- Pagination -->
        <nav class="d-flex justify-content-center">
            <ul class="pagination">
                <?php for($x=1; $x<=$numberOfPages; $x++) { ?>
                    <li class="page-item <?php if($x==$page){?>active<?php } ?>">
                        <a class="page-link" href="departments.php?page=<?php echo $x ?>"><?php echo $x ?></a>
                    </li>
                <?php } ?>
            </ul>
        </nav>
    </div>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

</body>
</html>
