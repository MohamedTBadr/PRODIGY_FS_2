
<?php
include 'mail.php';
if(!isset( $_SESSION['user_id'] )){
    header("location:login.php");
}
$Department="SELECT * from department ";
$runDepartment=mysqli_query($connect,$Department);
$Role="SELECT * from `role`";
$runRole=mysqli_query($connect,$Role);
if(isset( $_POST['signup'])){
$message='';

    $name=mysqli_real_escape_string($connect,$_POST['name']);
    $email=mysqli_real_escape_string($connect,$_POST['email']);
    $password=mysqli_real_escape_string($connect,$_POST['pass']);
    $cpassword=mysqli_real_escape_string($connect,$_POST['re_pass']);
    $department=mysqli_real_escape_string($connect, $_POST['department']);
    $role=mysqli_real_escape_string($connect, $_POST['role']);
    $pattern = '/[A-Z]/';  // Check for uppercase
    $pattern2 = '/[0-9]/';  // Check for number
    $pattern3 = '/[\W_]/';  // Check for special character
    $select="SELECT `EmployeeEmail` from employee where EmployeeEmail='$email'";
    $runSelect=mysqli_query($connect,$select);
    if(mysqli_num_rows($runSelect)>0){
        $message='<p class="err">account is already taken</p>';
    }elseif(empty($name)){
        $message="<p class='err'>name can't be empty</p>";
    }elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $message="<p class='err'>email format is wrong</p>";
    }elseif(empty($password)){
        $message="<p class='err'>password can't be empty</p>";
    }elseif(empty($cpassword)){
        $message="<p class='err'>name can't be empty</p>";
    }elseif(empty($department)){
$message='<p class="err">department must choosen</p>';
    }elseif (empty($role)) {
        $message='<p class="err">role must chosen</p>';
    }elseif($password!==$cpassword){
$message='<p class="err">password not matched confirm</p>';
    }elseif(!preg_match($pattern,$password) && !preg_match($pattern2,$password) && !preg_match($pattern3,$password)){
$message='<p class="err">password should contain at least 1 special character, 1 number,1 upper case</p>';
    }elseif(strlen($password)<5){
$message='<p class="err">password should be more than 5 letter</p>';
    }else{
        $salary=mysqli_real_escape_string($connect,$_POST['salary']);
        $time=date('Y-m-d');
        $hashedPass=password_hash($password,PASSWORD_DEFAULT);
        $insert="INSERT INTO `employee` values(null,'$name','$email','$hashedPass','$salary','$time','continue',$department,$role)";
        $runInsert=mysqli_query($connect,$insert);
        if($role == 3){
        $select="SELECT * FROM employee where EmployeeEmail='$email'";
        $runSelect=mysqli_query($connect,$select);
        $fetch=mysqli_fetch_assoc($runSelect);
        $id=$fetch['EmployeeId'];
        $update="UPDATE department set departmentHead='$id' where `departmentId`='$department'";
        $runUpdate=mysqli_query($connect,$update);
    }
    $message="<p class='success'>user added successfully</p>";

        $massage1 = "
        <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
            <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
                <h1>Password Reset Request</h1>
            </div>
            <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
                <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$name</span>,</p>
                <p style='color: #00000a ;'>We are happy to announce you that:</p>
                <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>your user has been created successfully</p>
                <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
                <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
            </div>
            <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
                <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
                <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
            </div>
        </body>
    
    ";
    
    
    
    $mail->setFrom('organizohelp@gmail.com', 'Organizo');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'Create Account';
    $mail->Body = $massage1;
    $mail->send();
    
}
}


if(isset($_GET['id'])){
    $id=mysqli_real_escape_string($connect,$_GET['id']);
}

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<!-- Main css -->
<link rel="stylesheet" href="css/style1.css">

</head>

<body>
    <div class="main">
        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Add Employee</h2>
                        <?php if(isset($message)){?>
                        
                            <?php echo $message ?>
                        
                        <?php } ?>

                        <form method="POST" class="register-form" id="register-form" oninput="enableSubmit()">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Employee Name" value="<?php echo isset($_POST['name']) ? $_POST['name'] : ''; ?>" oninput="validateName()"/>
                            </div>
                            <p id="nameError" class="err"></p>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Employee Email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" oninput="validateEmail()"/>
                            </div>
                            <p id="emailError" class="err"></p>

                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password"  value="<?php echo isset($_POST['pass']) ? $_POST['pass'] : ''; ?>"oninput="validatePassword()"/>
                                
                            </div>
                            <p id="passwordError" class="err"></p>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="re_pass" id="re_pass" value="<?php echo isset($_POST['re_pass']) ? $_POST['re_pass'] : ''; ?>" placeholder="Repeat Employee password" oninput="matchPass()"/>
                                
                            </div>
                            <p id="cpassError" class="err"></p>
                            <div class="form-group">
                                <label for="salary"><i class="fa-solid fa-dollar-sign"></i></label>
                                <input type="number" name="salary" id="salary" value="<?php echo isset($_POST['salary']) ? $_POST['salary'] : ''; ?>" placeholder="Repeat Employee salary" oninput="validateSalary()"/>
                            </div>
                            <p id="salaryError" class="err"></p>
                            <div class="form-group"><b>Department:</b>
                            <select name="department" class="form-select" aria-label="Default select example">

                                <?php foreach($runDepartment as $data){?>
                                    <option value="<?php echo $data['departmentId']?>"><?php echo $data['departmentName']?></option>

                                <?php } ?>
                                </select>

                                <!-- <p id="departmentError" class="err"></p> -->

                            </div>
                            <div class="form-group"><b>Role:</b>
                                
                                <select name="role" class="form-select" aria-label="Default select example">
                                    <?php foreach($runRole as $data){?>

                                     <option value="<?php echo $data['RoleId']?>"><?php echo $data['RoleName']?></option>
                                                                 <?php } ?>

                                                </select>
                            </div>
                            <div class="form-group form-button">
                                <button type="submit" name="signup" id="signup" class="form-submit" disabled>add member</button>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
                        <!-- <a href="login.php" class="signup-image-link">I am already member</a> -->
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script src="js/validations.js"></script>
<!-- <script src="vendor/jquery/jquery.min.js"></script> -->
    <script src="js/main.js"></script>
</body>
</html>