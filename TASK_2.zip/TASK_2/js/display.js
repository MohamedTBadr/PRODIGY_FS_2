document.addEventListener("DOMContentLoaded", function(event) {
    const toggle = document.getElementById('header-toggle');
    const nav = document.getElementById('nav-bar');
    const bodyPd = document.getElementById('body-pd');
    const headerPd = document.getElementById('header');

    // Check if elements exist
    if (toggle && nav && bodyPd && headerPd) {
        toggle.addEventListener('click', () => {
            // Add or remove 'show' class to toggle the side navigation
            nav.classList.toggle('show');
            // Add padding to the body when the navbar is shown
            bodyPd.classList.toggle('body-pd');
            // Adjust header position when navbar is shown
            headerPd.classList.toggle('body-pd');
        });
    }
});