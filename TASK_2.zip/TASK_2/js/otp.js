const inputs = document.querySelectorAll('.otp-input input');
const timerDisplay = document.getElementById('timer');
// const resendButton = document.getElementById('resendButton');
let timeLeft = 180; // 3 minutes in seconds
let timerId;

function startTimer() {
    timerId = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(timerId);
            timerDisplay.textContent = "OTP Code has expired!";
            // resendButton.disabled = false;
            inputs.forEach(input => input.disabled = true);
        } else {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            timerDisplay.textContent = `Time remaining: ${minutes}:${seconds.toString().padStart(2, '0')}`;
            timeLeft--;
        }
    }, 1000);
}





startTimer();