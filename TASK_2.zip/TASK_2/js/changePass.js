$(document).ready(function() {

    
    
    function validatePassword(){
      const password=document.getElementById('pass').value;
      const passwordError=document.getElementById('passwordError')
      const passNumber= /[1-9]/.test(password);
      const passUpperr= /[A-Z]/.test(password);
      const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

      if(password===""){
          passwordError.textContent="Password is required"
          return false
      }else if(!passNumber){
        passwordError.textContent="Password must contain at least one number"
        return false

      }
      else if(!passNumber){
        passwordError.textContent="Password must contain at least one number"
        return false

      }
      else if(!passUpperr){
        passwordError.textContent="Password must contain at least one upper letter"
        return false

      
      }else if(!hasSpecialChar){
        passwordError.textContent="Password must contain at least one special character"
        return false
      }else if ((password.length)<5){
        passwordError.textContent="Password must be more than 5 letters"
        return false
      }
      else{
          passwordError.textContent=""
          return true 
      }
    }
    
    
    
    function matchPass(){
        const password=document.getElementById('pass').value;
        const cpassword=document.getElementById('re_pass').value;
        const cpasswordError=document.getElementById('cpassError')

if(password !== cpassword){
cpasswordError.textContent="password not match confirm"
return false
}else{
    cpasswordError.textContent=''
    return true
}
    }
    
    function enableSubmit(){
        const passwordValid=validatePassword()
        const matchPassword=matchPass()
      const submitButton=document.getElementById('signup')
      if(passwordValid &&  matchPassword){
        submitButton.disabled=false;
    } else {
        submitButton.disabled=true;
    }
    }
    
    
    $('#pass ,#re_pass').on('keyup',function(){
        enableSubmit()
    })
    
    
    })
    
    
    
    document.getElementById('signup').on('click',function(event){
        event.preventDefault()
        

        
        })
    