$(document).ready(function() {


    
    function validateHead(){
      const password=document.getElementById('pass').value;
      const passwordError=document.getElementById('headError')
      if(password==""){
          passwordError.textContent="don't forget head"
          return false
      }else{
          passwordError.textContent=""
          return true 
      }
    }
    
    
    function validateDepartmentName(){
      var name=document.getElementById('name').value;
      var nameError=document.getElementById('departmentError')
    
      if(!name){
          nameError.textContent="Department Name is required"
          return false
      }
      else{
          nameError.textContent=""
          return true 
      }
    }
    
    
    function enableSubmit(){
        const DepartmentValid=validateDepartmentName()
        const headValid=validateHead()
        const submitButton=document.getElementById('submit')
        headValid
      if(DepartmentValid){
        submitButton.disabled=false;
    } else {
        submitButton.disabled=true;
    }
    }
    
    
    $('#name , #pass ').on('keyup',function(){
        enableSubmit()
    })
    
    
    })
    
    
    
    document.getElementById('signup').on('click',function(event){
        event.preventDefault()
        // var FormData={
        //     name: document.getElementById('name').value,
        //     password: document.getElementById('password').value,
        //     email: document.getElementById('email').value
        // }
        })
    