<?php 
include 'connection.php';
if(isset($_POST['submit'])){

    $email=mysqli_real_escape_string($connect,$_POST['email']);
    $pass=mysqli_real_escape_string($connect,$_POST['pass']);
$message='';
    $select="SELECT * FROM employee where EmployeeEmail ='$email' and Role !=2";
$run=mysqli_query($connect,$select);

if(mysqli_num_rows($run)>0){
    $fetchData=mysqli_fetch_assoc($run);
    $hashedPassword=$fetchData['EmployeePassword'];
    if(password_verify($pass,$hashedPassword)){
        $user_id=$fetchData['EmployeeId'];
        $role_id=$fetchData['Role'];
        $_SESSION['user_id']=$user_id;
        $_SESSION['role_id']=$role_id;
        $message='logged In succesfully';
        header("Refresh:2; url=index.php");

    }else{
        $message="password isn't correct";
    }
}else{
    $message="account isn't found";
}


}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Log In</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Main css -->
    <link rel="stylesheet" href="css/style1.css">
</head>
<body>

    <div class="main">

        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Log In</h2>
                        <?php if(isset($message)){?>
                            <p class="erre"><?php echo $message ?></p>
                       <?php } ?>
                        <form method="POST" class="register-form" id="login-form" oninput="enableSubmit()">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="email" id="name" placeholder="Your Email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>"oninput="validateEmail()"/>
                            </div>
                            <p id="emailError" class="err"></p>

                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password" value="<?php echo isset($_POST['pass']) ? $_POST['pass'] : ''; ?>" oninput="validatePassword()"/>
                            </div>
                            <p id="passwordError" class="err"></p>

                            <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div>
                            <div class="form-group form-button">
                                <button type="submit" name="submit" id="submit" class="form-submit" disabled>Log In</button>
                                <a href="forgetPass.php">forget password?</a>
                            </div>
                        </form>
                        <div class="social-login">
                            <span class="social-label">Or login with</span>
                            <ul class="socials">
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-facebook"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-twitter"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-google"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
     <script src="js/login.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>