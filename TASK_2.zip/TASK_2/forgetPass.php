<?php
include 'mail.php';
if(isset($_POST['submit'])){
$email=mysqli_real_escape_string($connect,$_POST['email']);
$message1='';
$select="SELECT EmployeeEmail from employee where EmployeeEmail='$email' and Role !=2 and status!='hold'";
    $runSelect=mysqli_query($connect,$select);
    
    if(!filter_var($email,FILTER_VALIDATE_EMAIL) ){
$message1 ='email format not true';
    }elseif(mysqli_num_rows($runSelect)==0){
        $message1='account is not found';}
    elseif(empty($email)){
        $message1 ='email cannot be empty';
    }else{
        $fetch=mysqli_fetch_assoc($runSelect);

$name=$fetch['Name'];
        $otp=rand(1000,9999);
        $time=time();
        $massageMail = "
        <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
            <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
                <h1>Password Reset Request</h1>
            </div>
            <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
                <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$name</span>,</p>
                <p style='color: #00000a ;'>Please use the OTP below to complete the process:</p>
                <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>$otp</p>
                <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
                <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
            </div>
            <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
                <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
                <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
            </div>
        </body>
    
    ";
    
    
    
    $mail->setFrom('organizohelp@gmail.com', 'Organizo');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'Reset Password';
    $mail->Body = ($massageMail);
    $mail->send();
    
    $_SESSION['otp'] = $otp;
    $_SESSION['time']=$time;
    $_SESSION['name']=$name;
    $_SESSION['email']=$email;
    
    header("location:otp.php?fr=");
    }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Forget Password</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Main css -->
    <link rel="stylesheet" href="css/style1.css">
</head>
<body>

    <div class="main">

        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Forget Password</h2>
                        <?php if(isset($message1)){?>
                            <p class="err"><?php echo $message1 ?></p>
                       <?php } ?>
                        <form method="POST" class="register-form" id="login-form" oninput="enableSubmit()">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="email" id="name" placeholder="Your Email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>"oninput="validateEmail()"/>
                            </div>
                            <p id="emailError" class="err"></p>

                            <div class="form-group form-button">
                                <button type="submit" name="submit" id="submit" class="form-submit" disabled>submit</button>
                            </div>
                        </form>
                        <!-- <div class="social-login">
                            <span class="social-label">Or login with</span>
                            <ul class="socials">
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-facebook"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-twitter"></i></a></li>
                                <li><a href="#"><i class="display-flex-center zmdi zmdi-google"></i></a></li>
                            </ul>
                        </div> -->
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
     <script src="js/forget.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>