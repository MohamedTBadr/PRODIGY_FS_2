<?php
    include 'connection.php';
    if(!isset( $_SESSION['user_id'] )){
        header("location:login.php");
    }
//employee department
    $EmployeePerRole="SELECT count(departmentName) as total , departmentName FROM  employee 
    join department on employee.DepartmentId=department.departmentId
        GROUP BY department.departmentName";
    $runEPR=mysqli_query($connect,$EmployeePerRole);

    $Departments=[];
    foreach ($runEPR as $fetch) {
        $Departments[]=[
         'total Employee'=>$fetch['total'],
         'Department Name'=>$fetch['departmentName']];
        
    }
    $data = json_encode($Departments);


    //started at
    $selectDate="SELECT *, DATE_FORMAT(startedAt,'%Y-%m') as`startedAt`  FROM employee join department on employee.DepartmentId=department.departmentId";

    $runDate=mysqli_query($connect,$selectDate);
$employeeDate=[];
$colors=[];
    foreach ($runDate as $key) {
        $departmentName = $key['departmentName'];

        if (empty($colors[$departmentName])) {
            $colors[$departmentName] = sprintf('#%06X', mt_rand(0, 0xFFFFFF)); // Random HEX color
        }
        $employeeDate[]=[
'startedAt'=>$key['startedAt'],
'employee name'=>$key['EmployeeName'],
'department name'=>$key['departmentName']
        ];
    }
    json_encode($employeeDate);


//----------------------------------------------------------------------------------//
//counters
$Select="SELECT count(*) as total FROM employee";
$runSelect=mysqli_query($connect,$Select);
$fetch=mysqli_fetch_array($runSelect);
$total=$fetch['total'];

$SelectD="SELECT count(*) as totalD FROM department";
$runSelectD=mysqli_query($connect,$SelectD);
$fetch=mysqli_fetch_array($runSelectD);
$DepartmentTotal=$fetch['totalD'];



$selectS="SELECT sum(salary) as totalS from employee";
$runS=mysqli_query( $connect,$selectS);
$fetchS=mysqli_fetch_array($runS);
$totalSalaries=$fetchS['totalS']
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="css/index.css">
    <title>home</title>
</head>
<body><br>
        <div class="container">
        <div class="row">
            <!-- Example Department Card -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total employee</h5>
                        <p class="card-text"> Total Number of Employees: <?php echo $total?></p>
                        <a href="displayEmployee.php" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-eye"></i> view
                        </a>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Department</h5>
                        <p class="card-text"> Total Number of Department: <?php echo $DepartmentTotal?></p>
                        <a href="displayDepartments.php" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-eye"></i> view
                        </a>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Salaries</h5>
                        <p class="card-text"> Total Salaries: <?php echo $totalSalaries?> $</p>
                        <a href="displayEmployee.php" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-eye"></i> view
                        </a>
                        </a>
                    </div>
                </div>
            </div>
</div>
</div>

    <div class="card1">
    <div class="chart-containerDate">
        <h5>Start Date of Employee</h5>
        <a href="displayEmployee.php">view details</a>
        <canvas id="employeeChart"></canvas>
    </div>
    </div>
    <div class="card1">
    <div class="chart-containerDepart">
        <h5>Employee per department</h5>
    <a href="displayEmployee.php">view details</a>

    <canvas id="DepartmentChart"></canvas>
</div>
</div>



<script>
    const employeeData = <?php echo json_encode($employeeDate); ?>;
    const departmentColors = " . json_encode($colors) . ";
    
    // Process the data to create labels (startedAt) and datasets (departments with employee count)
    const labels = [...new Set(employeeData.map(emp => emp.startedAt))]; // Unique startedAt dates
    
    // Group employees by department and date
    const departmentNames = [...new Set(employeeData.map(emp => emp['department name']))];
    const datasets = departmentNames.map(dept => {
        return {
            label: dept,
            data: labels.map(label => 
            employeeData.filter(emp => emp.startedAt === label && emp['department name'] === dept).length
        ),
            backgroundColor: departmentColors[dept], // Use color from PHP
        };
    });

    // Create the chart
    const ctx = document.getElementById('employeeChart').getContext('2d');
    const employeeChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels, // Unique dates (startedAt)
            datasets: datasets // Data grouped by departments
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    // stepSize: 1, // Add this line to set the increment to 1
                    ticks: {
            stepSize: 1, // Ensure the tick marks are spaced by 1 unit
            // callback: function(value) {
            //     return value; // Return the value as is, without any formatting
            // }
        }
                }
            }
        }
    });



    //second chart
     var data = <?php echo $data; ?>;

      // Extract the labels and data from the JSON object
      var labelsD = data.map(function(item) {
        return item['Department Name'];
      });
      var datasetsD = data.map(function(item) {
        return item['total Employee'];
      });

      // Create the chart
      var ctxx = document.getElementById("DepartmentChart").getContext("2d");
      var myChart = new Chart(ctxx, {
        type: 'bar',
        data: {
          labels: labelsD,
          datasets: [{
            label: "Employee Count",
            data: datasetsD,
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              
            ],
            borderWidth: 1
          }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    // stepSize: 1, // Add this line to set the increment to 1
                    ticks: {
            stepSize: 1, // Ensure the tick marks are spaced by 1 unit
            // callback: function(value) {
            //     return value; // Return the value as is, without any formatting
            // }
        }
                }
            }
        }
      });
</script>




</body>
</html>
