<?php

include 'mail.php';

if(!isset( $_SESSION['user_id'] )){
    header("location:login.php");
}

if(isset($_POST['searchBtn'])){
    $text=mysqli_real_escape_string($connect,$_POST['searchText']);
    $search="SELECT * FROM `employee`  join `role` on `employee`.`Role`=`role`.`RoleId` 
    left join `department` on `employee`.`DepartmentId`=`department`.`departmentId`
     where `EmployeeName` like '%$text%' or `EmployeeEmail` like '%$text%'
      or role.RoleName like '%$text%' or `department`.`departmentName` like '%$text%' ";
$runSearch=mysqli_query($connect,$search);

}

if(isset($_POST['sortingBtn'])){
    $sorting = $_POST['sorting']; // Set a default sorting column if none is provided
// echo "$sorting";
    $sort = "SELECT * FROM `employee`
             JOIN `role` ON `employee`.`Role` = `role`.`RoleId`
             JOIN `department` ON `employee`.`DepartmentId` = `department`.`departmentId`
             ORDER BY $sorting
             LIMIT $limit OFFSET $offset";

    $runSort = mysqli_query($connect, $sort);
     
}


if(isset($_POST['delete'])){
    $id=mysqli_real_escape_string($connect,$_POST['employeeId']);
    $delete="DELETE from employee where EmployeeId=$id";
    $runDelete=mysqli_query($connect,$delete);
    $uri=mysqli_real_escape_string($connect,$_SERVER['REQUEST_URI']);
    header("$uri");}
if(isset($_POST['hold'])){
    $id=mysqli_real_escape_string($connect,$_POST['employeeId']);
    $name=mysqli_real_escape_string($connect,$_POST['employeeName']);
    $email=mysqli_real_escape_string($connect,$_POST['employeeEmail']);

if (empty($name) || empty($email)) {
    echo "Error: Name or Email is empty.";
    exit();
}

echo "Name: $name, Email: $email"; // For debugging purposes

    $update="UPDATE employee set `status`='hold' where EmployeeId=$id";
    $runUpdate=mysqli_query($connect,$update);
    
    $massage1 = "
    <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
    <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
    <h1>Password Reset Request</h1>
    </div>
    <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
    <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$name</span>,</p>
    <p style='color: #00000a ;'>We are announce you that:</p>
    <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>your user has been hold</p>
    <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
    <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
    </div>
    <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
    <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
    <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
    </div>
    </body>
    
    ";
    
    
    
    $mail->setFrom('organizohelp@gmail.com', 'Organizo');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'hold Account';
    $mail->Body = $massage1;
    $mail->send();
    
    if($runUpdate){
        $uri=mysqli_real_escape_string($connect,$_SERVER['REQUEST_URI']);
    header("$uri");
    }
}

if(isset($_POST['unhold'])){
    $id=mysqli_real_escape_string($connect,$_POST['employeeId']);
    $name=mysqli_real_escape_string($connect,$_POST['employeeName']);
    $email=mysqli_real_escape_string($connect,$_POST['employeeEmail']);
    
    $update="UPDATE employee set `status`='continue' where EmployeeId=$id";
    $runUpdate=mysqli_query($connect,$update);
    $massage1 = "
    <body style='font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #fffffa ; color: #00000a ;'>
    <div style='background-color: #0a7273 ; padding: 20px ; text-align: center ; color: #fffffa ;'>
    <h1>Password Reset Request</h1>
    </div>
    <div style='padding: 20px ; background-color: #fffffa ; color: #00000a ;'>
    <p style='color: #00000a ;'>Dear <span style='color: #fda521;'>$name</span>,</p>
    <p style='color: #00000a ;'>We are announce you that:</p>
    <p style='color: #00000a ; text-align: center ; font-size: 24px ; font-weight: bold ; color: #fda521 ;'>your user has been unhold</p>
    <p style='color: #00000a ;'>if any problem happen please contact our support team for assistance.</p>
    <p style='color: #00000a ;'>Best regards,<br>The Organizo Team</p>
    </div>
    <div style='background-color: #0a7273; padding: 10px; text-align: center; color: #fffffa;'>
    <p style='color: #fffffa;'>For support and updates, please visit our website or contact us via email.</p>
    <p style='color: #fffffa;'>Email: <a href='mailto:organizohelp@gmail.com' style='color: #fda521;'>organizohelp@gmail.com</a></p>
    </div>
    </body>
    
    ";
    
    
    
    $mail->setFrom('organizohelp@gmail.com', 'Organizo');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'unhold Account';
    $mail->Body = $massage1;
    $mail->send();
    $uri=mysqli_real_escape_string($connect,$_SERVER['REQUEST_URI']);
    header("$uri");
}
$deapart=false;
$page=isset($_GET['page'])?mysqli_real_escape_string($connect,$_GET['page']):1;
$limit=5;
$offset=($page-1)*$limit;
if(isset($_GET['Depart'])){

$deapart=true;
    $departId=explode("?",mysqli_real_escape_string($connect,$_GET['Depart']));
    $departId=$departId[0];

$selectAll="SELECT count(*) as total FROM employee where employee.DepartmentId= $departId";
$runSelectAll=mysqli_query($connect,$selectAll);
$totalUser=mysqli_fetch_array($runSelectAll);
$totalPages=$totalUser['total'];
$numberOfPages=ceil($totalPages/$limit);
$select="SELECT * FROM `employee`  join `role` on `employee`.`Role`=`role`.`RoleId` left join `department` on `employee`.`DepartmentId`=`department`.`departmentId` where employee.DepartmentId= $departId limit $limit OFFSET $offset  ";
$runSelect=mysqli_query($connect,$select);

}else{

$selectAll="SELECT count(*) as total FROM employee";
$runSelectAll=mysqli_query($connect,$selectAll);
$totalUser=mysqli_fetch_array($runSelectAll);
$totalPages=$totalUser['total'];
$numberOfPages=ceil($totalPages/$limit);
$select="SELECT * FROM `employee`  join `role` on `employee`.`Role`=`role`.`RoleId` left join `department` on `employee`.`DepartmentId`=`department`.`departmentId` limit $limit OFFSET $offset ";
$runSelect=mysqli_query($connect,$select);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">


<title>staff</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap 5 CSS (prefer one version only) -->

<link rel="stylesheet" href="css/display.css">
</head>
<body id="body-pd">
 
<div class="container">
<div class="row">
<div class="col-lg-12 card-margin"><br><br>
<div class="card search-form">
<div class="card-body p-0">
<form id="search-form" method="POST">
<div class="row">
<div class="col-12">
<div class="row no-gutters">
<!-- <div class="col-lg-3 col-md-3 col-sm-12 p-0"> -->
    <!-- <select class="form-control" id="exampleFormControlSelect1">
        <option>Location</option>
        <option>London</option>
        <option>Boston</option>
<option>Mumbai</option>
<option>New York</option>
<option>Toronto</option>
<option>Paris</option>
</select> -->
<!-- </div> -->
<div class="col-lg-8 col-md-6 col-sm-12 p-0">
    <input type="text" placeholder="Search..." class="form-control" id="search" name="searchText">
</div>
<div class="col-lg-1 col-md-3 col-sm-12 p-0">
    <button type="submit" name="searchBtn" class="btn btn-base">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
</button>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="row">
</div>
<div class="col-12">
<div class="card card-margin">
<div class="card-body">
    <div class="row search-body">
        <div class="col-lg-12">
            <div class="search-result">
                <div class="result-header">
                    <div class="row">
                        <div class="col-lg-6">
                            </div>
                            <div class="col-lg-6">
                                <div class="result-actions">
                                    <form  method="POST">        
                                    <div class="result-sorting">
                                             <span>Sort By:</span>
                       
<select class="form-control border-0" name="sorting" id="exampleOption">
<option value="EmployeeName ASC">Names (A-Z)</option>
<option value="EmployeeName DESC">Names (Z-A)</option>
<option value="departmentName ASC">department (A-Z)</option>
<option value=" departmentName DESC">department (Z-A)</option>
<option value="salary ASC">salary (ASC)</option>
<option value=" salary DESC">salary (DESC)</option>
</select>
<button type="submit" name="sortingBtn" class="btn btn-base">
<i class="fa-solid fa-sort"></i>
</button>
</div>
</form>    
<div class="result-views">
<a href="addEmployee.php" class="btn btn-soft-base btn-icon">
<i class="fa-solid fa-plus"></i>
</a>
<!-- 
<button type="button" class="btn btn-soft-base btn-icon">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-grid">
<rect x="3" y="3" width="7" height="7"></rect>
<rect x="14" y="3" width="7" height="7"></rect>
<rect x="14" y="14" width="7" height="7"></rect>
<rect x="3" y="14" width="7" height="7"></rect>
</svg>
</button> -->
</div>
</div>
</div>
</div>
</div>
<div class="result-body">
<div class="table-responsive">

<table class="table widget-26">
    
<tbody>
    <thead>
        <tr>
            <th></th>
            <th>Name</th>
            <th>Role</th>
            <th>Salary</th>
            <th>Department</th>
            <th>Status</th>
            <th></th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
<?php if(isset($_POST['sortingBtn'])){?>
<?php foreach($runSort as $data){?>


<tr>
<td>
<div class="widget-26-job-emp-img">
<img src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="Company" />
</div>
</td>
<td>
<div class="widget-26-job-title">
<p ><?php echo $data['EmployeeName']?></p>
<p class="m-0"><a href="#" class="employer-name">started at:</a> <span class="text-muted time"><?php echo $data['startedAt']?></span></p>
</div>
</td>
<td>
<div class="widget-26-job-info">
<p class="type m-0"><?php echo ucfirst($data['RoleName'])?></p>
</div>
</td>
<td>
<div class="widget-26-job-salary">$<?php echo $data['salary']?></div>
</td>
<td>
<div class="widget-26-job-category bg-soft-info">
<i class="indicator bg-info"></i>
<span><?php echo $data['departmentName'];?></span>
</div>
</td>
<td>
<div class="widget-26-job-starred">
<!-- <a href="#">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star starred">
<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
</svg>
</a> -->
<?php echo $data['status']?>
</div>
</td>
<form method="post">
    <input type="hidden" name="employeeId" value="<?php echo $data['EmployeeId']?>">
  
    <input type="hidden" name="employeeName" value="<?php echo $data['EmployeeName']?>">
    <input type="hidden" name="employeeEmail" value="<?php echo $data['EmployeeEmail']?>">

    <td colspan="3"><a href="addEmployee.php?id=<?php echo $data['EmployeeId']?>" class="icon-button"><i class="fas fa-edit"></i></a> 
  <?php if($data['status']=='continue'){?>
    <button class="icon-button" type="submit" name="hold"><i class="fa fa-pause" aria-hidden="true"></i></button>
    <?php }else{?>
        <button class="icon-button" type="submit" name="unhold"><i class="fas fa-undo"></i></button>
        <?php } ?>
    <button class="icon-button" type="submit" name="delete"><i class="fa-solid fa-trash"></i></button>
    </td>
    <!-- <td><button class="icon-button" type="submit" name="delete"><i class="fa-solid fa-trash"></i></button></td> -->
</form>
</tr>
<?php } ?>




    <?php }elseif(isset($_POST['searchBtn'])){?>
<?php foreach($runSearch as $data){?>


<tr>
<td>
<div class="widget-26-job-emp-img">
<img src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="Company" />
</div>
</td>
<td>
<div class="widget-26-job-title">
<p ><?php echo $data['EmployeeName']?></p>
<p class="m-0"><a href="#" class="employer-name">started at:</a> <span class="text-muted time"><?php echo $data['startedAt']?></span></p>
</div>
</td>
<td>
<div class="widget-26-job-info">
<p class="type m-0"><?php echo ucfirst($data['RoleName'])?></p>
</div>
</td>
<td>
<div class="widget-26-job-salary">$<?php echo $data['salary']?></div>
</td>
<td>
<div class="widget-26-job-category bg-soft-info">
<i class="indicator bg-info"></i>
<span><?php echo $data['departmentName'];?></span>
</div>
</td>
<td>
<div class="widget-26-job-starred">
<!-- <a href="#">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star starred">
<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
</svg>
</a> -->
<?php echo $data['status']?>
</div>
</td>
<form method="post">
    <input type="hidden" name="employeeId" value="<?php echo $data['EmployeeId']?>">
  
    <input type="hidden" name="employeeName" value="<?php echo $data['EmployeeName']?>">
    <input type="hidden" name="employeeEmail" value="<?php echo $data['EmployeeEmail']?>">

    <td colspan="3"><a href="addEmployee.php?id=<?php echo $data['EmployeeId']?>" class="icon-button"><i class="fas fa-edit"></i></a> 
  <?php if($data['status']=='continue'){?>
    <button class="icon-button" type="submit" name="hold"><i class="fa fa-pause" aria-hidden="true"></i></button>
    <?php }else{?>
        <button class="icon-button" type="submit" name="unhold"><i class="fas fa-undo"></i></button>
        <?php } ?>
    <button class="icon-button" type="submit" name="delete"><i class="fa-solid fa-trash"></i></button>
    </td>
    <!-- <td><button class="icon-button" type="submit" name="delete"><i class="fa-solid fa-trash"></i></button></td> -->
</form>
</tr>
<?php } ?>



<?php }else{ ?>
<?php foreach($runSelect as $data){?>
<tr>
<td>
<div class="widget-26-job-emp-img">
<img src="https://bootdey.com/img/Content/avatar/avatar6.png" alt="Company" />
</div>
</td>
<td>
<div class="widget-26-job-title">
<p ><?php echo $data['EmployeeName']?></p>
<p class="m-0"><a href="#" class="employer-name">started at:</a> <span class="text-muted time"><?php echo $data['startedAt']?></span></p>
</div>
</td>
<td>
<div class="widget-26-job-info">
<p class="type m-0"><?php echo ucfirst($data['RoleName'])?></p>
</div>
</td>
<td>
<div class="widget-26-job-salary">$<?php echo $data['salary']?></div>
</td>
<td>
<div class="widget-26-job-category bg-soft-info">
<i class="indicator bg-info"></i>
<span><?php echo $data['departmentName'];?></span>
</div>
</td>
<td>
<div class="widget-26-job-starred">
<!-- <a href="#">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star starred">
<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
</svg>
</a> -->
<?php echo $data['status']?>
</div>
</td>
<form method="post">
    <input type="hidden" name="employeeId" value="<?php echo $data['EmployeeId']?>">
  
    <input type="hidden" name="employeeName" value="<?php echo $data['EmployeeName']?>">
    <input type="hidden" name="employeeEmail" value="<?php echo $data['EmployeeEmail']?>">

    <td colspan="3"><a href="addEmployee.php?id=<?php echo $data['EmployeeId']?>" class="icon-button"><i class="fas fa-edit"></i></a> 
  <?php if($data['status']=='continue'){?>
    <button class="icon-button" type="submit" name="hold"><i class="fa fa-pause" aria-hidden="true"></i></button>
    <?php }else{?>
        <button class="icon-button" type="submit" name="unhold"><i class="fas fa-undo"></i></button>
        <?php } ?>
    <button class="icon-button" type="submit" name="delete"><i class="fa-solid fa-trash"></i></button>
    </td>
    <!-- <td><button class="icon-button" type="submit" name="delete"><i class="fa-solid fa-trash"></i></button></td> -->
</form>
</tr>
<?php }} ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>

<nav class="d-flex justify-content-center">
<ul class="pagination pagination-base pagination-boxed pagination-square mb-0">
<!-- <li class="page-item">
<a class="page-link no-border" href="#">
<span aria-hidden="true">«</span>
<span class="sr-only">Previous</span>
</a>
</li> -->

<?php for($x=1;$x<=$numberOfPages;$x++){?>
<li class="page-item<?php if($x==$page){?> active <?php } ?>"><a class="page-link no-border" 
href="displayEmployee.php?page=<?php echo $x ?><?php if($deapart){echo '&&Depart='.$departId;}  ?>"><?php echo $x?></a></li>
<?php } ?>
<!-- <li class="page-item">
<a class="page-link no-border" href="#">
<span aria-hidden="true">»</span>
<span class="sr-only">Next</span>
</a>
</li> -->

</ul>
</nav>
</div>
</div>
</div>
</div>
</div>


</body>
</html>