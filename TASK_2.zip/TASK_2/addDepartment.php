<?php
include 'connection.php';
if(!isset( $_SESSION['user_id'] )){
    header("location:login.php");
}

$DepartmentName='';
$DepartmentHead='';
$message='';
$select="SELECT * FROM employee";
$runselect=mysqli_query($connect,$select);
if(isset($_POST['submit'])){
    $DepartmentName=mysqli_real_escape_string($connect,$_POST['name']);
    if(isset($_POST['head'])){
    $DepartmentHead=mysqli_real_escape_string($connect,$_POST['head']);
   }else{
    $DepartmentHead=null;
   }


    if(empty($DepartmentName)){
         $message='<p class="err">Department Name is neededd</p>';
    }

    echo $DepartmentHead;
    $insert="INSERT INTO department values(null,'$DepartmentName',$DepartmentHead)";
    $runInsert=mysqli_query($connect,$insert);
    $message='<p class="success">department added successfully</p>';
    if($runInsert){
        $updateRole="UPDATE employee set Role=1 where EmployeeId='$DepartmentHead'";
        $runUpdateRole=mysqli_query($connect,$updateRole);
    }
}
$edit=false;
if(isset($_GET['editDepart'])){
    $edit=true;
$id=mysqli_real_escape_string($connect,$_GET['editDepart']);
$select="SELECT * FROM department where departmentId=$id";
$runSelect=mysqli_query($connect,$select);
$fetch=mysqli_fetch_assoc($runSelect);
$DepartmentName=$fetch['departmentName'];
$DepartmentHead=$fetch['departmentHead'];
if($DepartmentHead!==null){
    $select="SELECT * FROM employee where EmployeeId=$DepartmentHead";
    $runselect=mysqli_query($connect,$select);
    $fetch2=mysqli_fetch_assoc($runselect);
    $DepartmentHeadName=$fetch2['EmployeeName'];
}else{
    $DepartmentHeadName=null;
}

if(isset($_POST['edit'])){
    $DepartmentName=mysqli_real_escape_string($connect,$_POST['name']);
    $DepartmentHead=mysqli_real_escape_string($connect,$_POST['head']);
    $insert="UPDATE department set departmentName='$DepartmentName',departmentHead='$DepartmentHead' where departmentId='$id'";
    $runInsert=mysqli_query($connect,$insert);
    $message='<p class="success">department has been edited successfully</p>';
    header("Refresh:2;url=departments.php");
}
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Log In</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Main css -->
    <link rel="stylesheet" href="css/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    </head>
<body>

    <div class="main">

        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                   
                    <div class="signin-form">
                        <h2 class="form-title">Add department</h2>
                        <?php if(isset($message)){?>
                            <p class="erre"><?php echo $message ?></p>
                       <?php } ?>
                        <form method="POST" class="register-form" id="login-form" oninput="enableSubmit()">
                            <div class="form-group">
                                <label for="name"><i class="fas fa-building"></i>
                                </i>
                                </label>
                                <input type="text" name="name" id="name" placeholder="Department Name" value="<?php echo $DepartmentName ?>"oninput="validateDepartmentName()"/>
                            </div>
                            <p id="departmentError" class="err"></p>

                            <div class="form-group">
                                <label for="pass"><i class="fas fa-user-tie"></i>Department Head:</label><br><br><br>
                                <select class="form-select" id="pass" name="head" aria-label="Default select example" oninput="validateHead()">
                                    <?php if($edit){?>
                                        <option value="<?php echo $DepartmentHead?>"><?php isset($DepartmentHeadName)?></option>
                                        <?php }else{?>
                                            <?php } ?>
                                            <?php foreach($runselect as $data){?>
                                            <option value="<?php echo $data['EmployeeId']?>" value="<?php echo $DepartmentHead?>"><?php echo $data['EmployeeName']?></option>
                                            <?php } ?>
                                </select>
                            </div>
                            <p id="headError" class="err"></p>
<?php if($edit){?>
                            <div class="form-group form-button">
                                <button type="submit" name="edit" id="submit" class="form-submit" disabled>edit department</button>
                            </div>
                            <?php }else{?>
                            <div class="form-group form-button">
                                <button type="submit" name="submit" id="submit" class="form-submit" disabled>Add department</button>
                            </div>
                            <?php } ?>
                        </form>
                        
                    </div>
                    <div class="signin-image">
                                <figure><img src="images/Depart.png" alt="sing up image"></figure>
                            </div>
                </div>
            </div>

        </section>

    </div>

    <!-- JS -->
     <script src="js/addEdit.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>